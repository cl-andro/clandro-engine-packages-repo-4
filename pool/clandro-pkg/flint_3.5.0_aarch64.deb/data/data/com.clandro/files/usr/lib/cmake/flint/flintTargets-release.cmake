#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "flint::flint" for configuration "Release"
set_property(TARGET flint::flint APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(flint::flint PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libflint.so"
  IMPORTED_SONAME_RELEASE "libflint.so"
  )

list(APPEND _cmake_import_check_targets flint::flint )
list(APPEND _cmake_import_check_files_for_flint::flint "${_IMPORT_PREFIX}/lib/libflint.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
