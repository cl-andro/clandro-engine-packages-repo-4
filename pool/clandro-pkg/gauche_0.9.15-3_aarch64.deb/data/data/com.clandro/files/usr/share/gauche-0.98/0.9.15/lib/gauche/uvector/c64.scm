;; Generated automatically.  Do not edit
(define-module
 gauche.uvector.c64
 (use gauche.uvector)
 (export make-c64vector c64vector c64vector? c64vector-length c64vector-ref
  c64vector-set! c64vector->list list->c64vector c64?)
 (export c64vector-unfold c64vector-unfold-right c64vector-copy
  c64vector-reverse-copy c64vector-append c64vector-concatenate
  c64vector-append-subvectors c64vector-empty? c64vector= c64vector-take
  c64vector-take-right c64vector-drop c64vector-drop-right c64vector-segment
  c64vector-fold c64vector-fold-right c64vector-map c64vector-map!
  c64vector-for-each c64vector-count c64vector-cumulate c64vector-take-while
  c64vector-take-while-right c64vector-drop-while c64vector-drop-while-right
  c64vector-index c64vector-index-right c64vector-skip c64vector-skip-right
  c64vector-any c64vector-every c64vector-partition c64vector-filter
  c64vector-remove c64vector-swap! c64vector-fill! c64vector-reverse!
  c64vector-copy! c64vector-reverse-copy! c64vector-unfold!
  c64vector-unfold-right! reverse-list->c64vector reverse-c64vector->list
  c64vector->vector vector->c64vector make-c64vector-generator write-c64vector
  c64vector-comparator))
