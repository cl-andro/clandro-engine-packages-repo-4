;; generated automatically.  DO NOT EDIT
#!no-fold-case
(define-module dbm.odbm (extend dbm) (use scheme.list) (export <odbm> odbm-init odbm-close odbm-closed? odbm-store odbm-fetch odbm-delete odbm-firstkey odbm-nextkey))
(select-module dbm.odbm)
(dynamic-load "dbm--odbm")
