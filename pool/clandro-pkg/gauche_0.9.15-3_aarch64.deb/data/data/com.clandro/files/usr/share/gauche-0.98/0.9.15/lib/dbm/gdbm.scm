;; generated automatically.  DO NOT EDIT
#!no-fold-case
(define-module dbm.gdbm (extend dbm) (export <gdbm> gdbm-open gdbm-close gdbm-closed? gdbm-store gdbm-fetch gdbm-delete gdbm-firstkey gdbm-nextkey gdbm-reorganize gdbm-sync gdbm-exists? gdbm-strerror gdbm-setopt gdbm-version gdbm-file-of gdbm-errno GDBM_READER GDBM_WRITER GDBM_WRCREAT GDBM_NEWDB GDBM_FAST GDBM_SYNC GDBM_NOLOCK GDBM_INSERT GDBM_REPLACE GDBM_CACHESIZE GDBM_FASTMODE GDBM_SYNCMODE GDBM_CENTFREE GDBM_COALESCEBLKS))
(select-module dbm.gdbm)
(dynamic-load "dbm--gdbm")
