;; generated automatically.  DO NOT EDIT
#!no-fold-case
(define-module dbm.ndbm (extend dbm) (use scheme.list) (use util.match) (export <ndbm> ndbm-open ndbm-close ndbm-closed? ndbm-store ndbm-fetch ndbm-exists? ndbm-delete ndbm-firstkey ndbm-nextkey ndbm-error ndbm-clearerror DBM_INSERT DBM_REPLACE))
(select-module dbm.ndbm)
(dynamic-load "dbm--ndbm")
