;; Generated automatically.  Do not edit
(define-module
 gauche.uvector.f32
 (use gauche.uvector)
 (export make-f32vector f32vector f32vector? f32vector-length f32vector-ref
  f32vector-set! f32vector->list list->f32vector f32?)
 (export f32vector-unfold f32vector-unfold-right f32vector-copy
  f32vector-reverse-copy f32vector-append f32vector-concatenate
  f32vector-append-subvectors f32vector-empty? f32vector= f32vector-take
  f32vector-take-right f32vector-drop f32vector-drop-right f32vector-segment
  f32vector-fold f32vector-fold-right f32vector-map f32vector-map!
  f32vector-for-each f32vector-count f32vector-cumulate f32vector-take-while
  f32vector-take-while-right f32vector-drop-while f32vector-drop-while-right
  f32vector-index f32vector-index-right f32vector-skip f32vector-skip-right
  f32vector-any f32vector-every f32vector-partition f32vector-filter
  f32vector-remove f32vector-swap! f32vector-fill! f32vector-reverse!
  f32vector-copy! f32vector-reverse-copy! f32vector-unfold!
  f32vector-unfold-right! reverse-list->f32vector reverse-f32vector->list
  f32vector->vector vector->f32vector make-f32vector-generator write-f32vector
  f32vector-comparator))
