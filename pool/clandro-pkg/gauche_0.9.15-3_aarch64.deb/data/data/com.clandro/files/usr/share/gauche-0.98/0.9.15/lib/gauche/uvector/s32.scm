;; Generated automatically.  Do not edit
(define-module
 gauche.uvector.s32
 (use gauche.uvector)
 (export make-s32vector s32vector s32vector? s32vector-length s32vector-ref
  s32vector-set! s32vector->list list->s32vector s32?)
 (export s32vector-unfold s32vector-unfold-right s32vector-copy
  s32vector-reverse-copy s32vector-append s32vector-concatenate
  s32vector-append-subvectors s32vector-empty? s32vector= s32vector-take
  s32vector-take-right s32vector-drop s32vector-drop-right s32vector-segment
  s32vector-fold s32vector-fold-right s32vector-map s32vector-map!
  s32vector-for-each s32vector-count s32vector-cumulate s32vector-take-while
  s32vector-take-while-right s32vector-drop-while s32vector-drop-while-right
  s32vector-index s32vector-index-right s32vector-skip s32vector-skip-right
  s32vector-any s32vector-every s32vector-partition s32vector-filter
  s32vector-remove s32vector-swap! s32vector-fill! s32vector-reverse!
  s32vector-copy! s32vector-reverse-copy! s32vector-unfold!
  s32vector-unfold-right! reverse-list->s32vector reverse-s32vector->list
  s32vector->vector vector->s32vector make-s32vector-generator write-s32vector
  s32vector-comparator))
