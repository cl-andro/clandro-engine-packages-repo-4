;; Generated automatically.  Do not edit
(define-module
 gauche.uvector.u8
 (use gauche.uvector)
 (export make-u8vector u8vector u8vector? u8vector-length u8vector-ref
  u8vector-set! u8vector->list list->u8vector u8?)
 (export u8vector-unfold u8vector-unfold-right u8vector-copy
  u8vector-reverse-copy u8vector-append u8vector-concatenate
  u8vector-append-subvectors u8vector-empty? u8vector= u8vector-take
  u8vector-take-right u8vector-drop u8vector-drop-right u8vector-segment
  u8vector-fold u8vector-fold-right u8vector-map u8vector-map!
  u8vector-for-each u8vector-count u8vector-cumulate u8vector-take-while
  u8vector-take-while-right u8vector-drop-while u8vector-drop-while-right
  u8vector-index u8vector-index-right u8vector-skip u8vector-skip-right
  u8vector-any u8vector-every u8vector-partition u8vector-filter
  u8vector-remove u8vector-swap! u8vector-fill! u8vector-reverse!
  u8vector-copy! u8vector-reverse-copy! u8vector-unfold!
  u8vector-unfold-right! reverse-list->u8vector reverse-u8vector->list
  u8vector->vector vector->u8vector make-u8vector-generator write-u8vector
  u8vector-comparator))
