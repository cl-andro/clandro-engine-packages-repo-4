;; generated automatically.  DO NOT EDIT
#!no-fold-case
(define-module rfc.tls (use gauche.vport) (use gauche.connection) (use gauche.net) (use util.match) (export <tls> make-tls tls-connect tls-bind tls-accept tls-poll tls-close tls-load-certificate tls-load-private-key tls-read tls-write tls-input-port tls-output-port tls-ca-bundle-path default-tls-class connection-self-address connection-peer-address connection-input-port connection-output-port connection-shutdown connection-close SSL_SERVER_VERIFY_LATER SSL_CLIENT_AUTHENTICATION SSL_DISPLAY_BYTES SSL_DISPLAY_STATES SSL_DISPLAY_CERTS SSL_DISPLAY_RSA SSL_CONNECT_IN_PARTS SSL_NO_DEFAULT_KEY SSL_OBJ_X509_CERT SSL_OBJ_X509_CACERT SSL_OBJ_RSA_KEY SSL_OBJ_PKCS8 SSL_OBJ_PKCS12 tls-load-object tls-destroy))
(select-module rfc.tls)
(dynamic-load "rfc--tls")
