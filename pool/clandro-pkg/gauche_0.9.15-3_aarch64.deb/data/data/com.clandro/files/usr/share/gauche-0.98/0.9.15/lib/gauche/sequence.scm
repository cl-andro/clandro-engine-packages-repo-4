;; generated automatically.  DO NOT EDIT
#!no-fold-case
(define-module gauche.sequence (extend gauche.collection) (export referencer modifier subseq call-with-reverse-iterator call-with-reverse-iterators fold-right fold-with-index map-with-index map-to-with-index for-each-with-index find-index find-with-index group-sequence group-contiguous-sequence delete-neighbor-dups delete-neighbor-dups! delete-neighbor-dups-squeeze! sequence->kmp-stepper sequence-contains break-list-by-sequence! break-list-by-sequence common-prefix-to common-prefix inverse-permuter permute-to permute permute! unpermute-to unpermute unpermute! shuffle-to shuffle shuffle!))
(select-module gauche.sequence)
(dynamic-load "gauche--sequence")
