/data/data/com.clandro/files/usr/bin/direnv hook fish | source
