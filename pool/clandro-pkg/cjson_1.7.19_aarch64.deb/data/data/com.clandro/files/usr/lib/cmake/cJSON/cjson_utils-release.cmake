#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cjson_utils" for configuration "Release"
set_property(TARGET cjson_utils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(cjson_utils PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libcjson_utils.so"
  IMPORTED_SONAME_RELEASE "libcjson_utils.so"
  )

list(APPEND _cmake_import_check_targets cjson_utils )
list(APPEND _cmake_import_check_files_for_cjson_utils "/data/data/com.clandro/files/usr/lib/libcjson_utils.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
