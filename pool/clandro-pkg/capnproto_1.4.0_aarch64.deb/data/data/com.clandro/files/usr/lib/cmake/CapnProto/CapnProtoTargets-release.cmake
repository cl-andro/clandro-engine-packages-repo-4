#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CapnProto::kj" for configuration "Release"
set_property(TARGET CapnProto::kj APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::kj PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libkj.so"
  IMPORTED_SONAME_RELEASE "libkj.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::kj )
list(APPEND _cmake_import_check_files_for_CapnProto::kj "/data/data/com.clandro/files/usr/lib/libkj.so" )

# Import target "CapnProto::kj-test" for configuration "Release"
set_property(TARGET CapnProto::kj-test APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::kj-test PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libkj-test.so"
  IMPORTED_SONAME_RELEASE "libkj-test.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::kj-test )
list(APPEND _cmake_import_check_files_for_CapnProto::kj-test "/data/data/com.clandro/files/usr/lib/libkj-test.so" )

# Import target "CapnProto::kj-async" for configuration "Release"
set_property(TARGET CapnProto::kj-async APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::kj-async PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libkj-async.so"
  IMPORTED_SONAME_RELEASE "libkj-async.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::kj-async )
list(APPEND _cmake_import_check_files_for_CapnProto::kj-async "/data/data/com.clandro/files/usr/lib/libkj-async.so" )

# Import target "CapnProto::kj-http" for configuration "Release"
set_property(TARGET CapnProto::kj-http APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::kj-http PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libkj-http.so"
  IMPORTED_SONAME_RELEASE "libkj-http.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::kj-http )
list(APPEND _cmake_import_check_files_for_CapnProto::kj-http "/data/data/com.clandro/files/usr/lib/libkj-http.so" )

# Import target "CapnProto::kj-tls" for configuration "Release"
set_property(TARGET CapnProto::kj-tls APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::kj-tls PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libkj-tls.so"
  IMPORTED_SONAME_RELEASE "libkj-tls.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::kj-tls )
list(APPEND _cmake_import_check_files_for_CapnProto::kj-tls "/data/data/com.clandro/files/usr/lib/libkj-tls.so" )

# Import target "CapnProto::kj-gzip" for configuration "Release"
set_property(TARGET CapnProto::kj-gzip APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::kj-gzip PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libkj-gzip.so"
  IMPORTED_SONAME_RELEASE "libkj-gzip.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::kj-gzip )
list(APPEND _cmake_import_check_files_for_CapnProto::kj-gzip "/data/data/com.clandro/files/usr/lib/libkj-gzip.so" )

# Import target "CapnProto::capnp" for configuration "Release"
set_property(TARGET CapnProto::capnp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnp PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libcapnp.so"
  IMPORTED_SONAME_RELEASE "libcapnp.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnp )
list(APPEND _cmake_import_check_files_for_CapnProto::capnp "/data/data/com.clandro/files/usr/lib/libcapnp.so" )

# Import target "CapnProto::capnp-rpc" for configuration "Release"
set_property(TARGET CapnProto::capnp-rpc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnp-rpc PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libcapnp-rpc.so"
  IMPORTED_SONAME_RELEASE "libcapnp-rpc.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnp-rpc )
list(APPEND _cmake_import_check_files_for_CapnProto::capnp-rpc "/data/data/com.clandro/files/usr/lib/libcapnp-rpc.so" )

# Import target "CapnProto::capnp-json" for configuration "Release"
set_property(TARGET CapnProto::capnp-json APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnp-json PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libcapnp-json.so"
  IMPORTED_SONAME_RELEASE "libcapnp-json.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnp-json )
list(APPEND _cmake_import_check_files_for_CapnProto::capnp-json "/data/data/com.clandro/files/usr/lib/libcapnp-json.so" )

# Import target "CapnProto::capnp-websocket" for configuration "Release"
set_property(TARGET CapnProto::capnp-websocket APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnp-websocket PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libcapnp-websocket.so"
  IMPORTED_SONAME_RELEASE "libcapnp-websocket.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnp-websocket )
list(APPEND _cmake_import_check_files_for_CapnProto::capnp-websocket "/data/data/com.clandro/files/usr/lib/libcapnp-websocket.so" )

# Import target "CapnProto::capnpc" for configuration "Release"
set_property(TARGET CapnProto::capnpc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnpc PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libcapnpc.so"
  IMPORTED_SONAME_RELEASE "libcapnpc.so"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnpc )
list(APPEND _cmake_import_check_files_for_CapnProto::capnpc "/data/data/com.clandro/files/usr/lib/libcapnpc.so" )

# Import target "CapnProto::capnp_tool" for configuration "Release"
set_property(TARGET CapnProto::capnp_tool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnp_tool PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/capnp"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnp_tool )
list(APPEND _cmake_import_check_files_for_CapnProto::capnp_tool "${_IMPORT_PREFIX}/bin/capnp" )

# Import target "CapnProto::capnpc_cpp" for configuration "Release"
set_property(TARGET CapnProto::capnpc_cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnpc_cpp PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/capnpc-c++"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnpc_cpp )
list(APPEND _cmake_import_check_files_for_CapnProto::capnpc_cpp "${_IMPORT_PREFIX}/bin/capnpc-c++" )

# Import target "CapnProto::capnpc_capnp" for configuration "Release"
set_property(TARGET CapnProto::capnpc_capnp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CapnProto::capnpc_capnp PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/capnpc-capnp"
  )

list(APPEND _cmake_import_check_targets CapnProto::capnpc_capnp )
list(APPEND _cmake_import_check_files_for_CapnProto::capnpc_capnp "${_IMPORT_PREFIX}/bin/capnpc-capnp" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
