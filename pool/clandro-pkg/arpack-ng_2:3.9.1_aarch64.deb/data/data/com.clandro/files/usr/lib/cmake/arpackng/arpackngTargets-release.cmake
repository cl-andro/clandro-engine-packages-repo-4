#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "arpack" for configuration "Release"
set_property(TARGET arpack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(arpack PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libarpack.so.2.1.0"
  IMPORTED_SONAME_RELEASE "libarpack.so.2"
  )

list(APPEND _cmake_import_check_targets arpack )
list(APPEND _cmake_import_check_files_for_arpack "/data/data/com.clandro/files/usr/lib/libarpack.so.2.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
