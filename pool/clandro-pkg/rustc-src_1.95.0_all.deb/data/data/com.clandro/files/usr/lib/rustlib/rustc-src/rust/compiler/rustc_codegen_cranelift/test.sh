#!/data/data/com.clandro/files/usr/bin/sh
exec ./y.sh test "$@"
