# `megaco_transport`
[🔗](https://github.com/erlang/otp/blob/master/lib/megaco/src/engine/megaco_transport.erl#L28)

Megaco transport behaviour.

The following functions should be exported from a `megaco_transport` callback
module:

- `c:send_message/2` [`mandatory`]
- `c:send_message/3` [`optional`]
- `c:resend_message/2` [`optional`]

# `resend_message`
*optional* 

```elixir
-callback resend_message(Handle, Msg) -> ok | {cancel, Reason :: term()} | Error
                            when Handle :: term(), Msg :: iodata(), Error :: term().
```

Re-send a megaco message.

Note that this function will only be called if the user has set the
[resend_indication](`m:megaco#ui_resend_indication`) config option to
`true`_and_ it is in fact a message resend. If not _both_ of these condition's
are meet, `send_message` will be called.

If the function returns `{cancel, Reason}`, this means the transport module
decided not to send the message. This is _not_ an error. No error messages will
be issued and no error counters incremented. What actions this will result in
depends on what kind of message was sent.

In the case of requests, megaco will cancel the message in much the same way as
if `megaco:cancel` had been called (after a successfull send). The information
will be propagated back to the user differently depending on how the request(s)
where issued: For requests issued using [megaco:call](`megaco:call/3`), the info
will be delivered in the return value. For requests issued using `megaco:cast`
the info will be delivered via a call to the callback function
[handle_trans_reply](`c:megaco_user:handle_trans_reply/5`).

In the case of reply, megaco will cancel the reply and information of this will
be returned to the user via a call to the callback function
[handle_trans_ack](`c:megaco_user:handle_trans_ack/5`).

# `send_message`

```elixir
-callback send_message(Handle, Msg) -> ok | {cancel, Reason :: term()} | Error
                          when Handle :: term(), Msg :: iodata(), Error :: term().
```

# `send_message`
*optional* 

```elixir
-callback send_message(Handle, Msg, Resend) -> ok | {cancel, Reason :: term()} | Error
                          when Handle :: term(), Msg :: iodata(), Resend :: boolean(), Error :: term().
```

Send a megaco message.

If the function returns `{cancel, Reason}`, this means the transport module
decided not to send the message. This is _not_ an error. No error messages will
be issued and no error counters incremented. What actions this will result in
depends on what kind of message was sent.

In the case of requests, megaco will cancel the message in much the same way as
if `megaco:cancel` had been called (after a successfull send). The information
will be propagated back to the user differently depending on how the request(s)
where issued: For requests issued using `megaco:call/3`, the info
will be delivered in the return value. For requests issued using `megaco:cast`
the info will be delivered via a call to the callback function
[handle_trans_reply](`c:megaco_user:handle_trans_reply/5`).

In the case of reply, megaco will cancel the reply and information of this will
be returned to the user via a call to the callback function
[handle_trans_ack](`c:megaco_user:handle_trans_ack/5`).

The function [`send_message/3`](`c:send_message/3`) will only be called if the
[resend_indication](`m:megaco#ui_resend_indication`) config option has been set
to the value `flag`. The third argument, `Resend` then indicates if the message
send is a resend or not.

---

*Consult [api-reference.md](api-reference.md) for complete listing*
