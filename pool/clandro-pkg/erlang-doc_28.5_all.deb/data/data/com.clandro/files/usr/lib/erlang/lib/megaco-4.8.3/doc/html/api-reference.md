# megaco v4.8.3 - API Reference

## Modules

- [megaco](megaco.md): Main API of the Megaco application
- [megaco_codec_meas](megaco_codec_meas.md): This module implements a simple megaco codec measurement tool.
- [megaco_codec_mstone1](megaco_codec_mstone1.md): This module implements a simple megaco codec-based performance tool.
- [megaco_codec_mstone2](megaco_codec_mstone2.md): This module implements a simple megaco codec-based performance tool.
- [megaco_codec_transform](megaco_codec_transform.md): Megaco message transformation utility.
- [megaco_digit_map](megaco_digit_map.md): Digit Map utility module.
- [megaco_edist_compress](megaco_edist_compress.md): Megaco erlang dist compress behaviour.
- [megaco_encoder](megaco_encoder.md): Megaco encoder behaviour.
- [megaco_flex_scanner](megaco_flex_scanner.md): Interface module to the flex scanner linked in driver.
- [megaco_sdp](megaco_sdp.md): SDP utility module.
- [megaco_tcp](megaco_tcp.md): Interface module to TPKT transport protocol for Megaco/H.248.
- [megaco_transport](megaco_transport.md): Megaco transport behaviour.
- [megaco_udp](megaco_udp.md): Interface module to UDP transport protocol for Megaco/H.248.
- [megaco_user](megaco_user.md): Callback module for users of the Megaco application

