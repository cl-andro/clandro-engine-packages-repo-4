#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "brainfuck::brainfuck" for configuration "Release"
set_property(TARGET brainfuck::brainfuck APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(brainfuck::brainfuck PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libbrainfuck.a"
  )

list(APPEND _cmake_import_check_targets brainfuck::brainfuck )
list(APPEND _cmake_import_check_files_for_brainfuck::brainfuck "/data/data/com.clandro/files/usr/lib/libbrainfuck.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
