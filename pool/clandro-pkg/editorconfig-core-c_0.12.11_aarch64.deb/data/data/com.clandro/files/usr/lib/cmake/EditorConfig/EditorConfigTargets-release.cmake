#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "editorconfig_static" for configuration "Release"
set_property(TARGET editorconfig_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(editorconfig_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libeditorconfig_static.a"
  )

list(APPEND _cmake_import_check_targets editorconfig_static )
list(APPEND _cmake_import_check_files_for_editorconfig_static "/data/data/com.clandro/files/usr/lib/libeditorconfig_static.a" )

# Import target "editorconfig_shared" for configuration "Release"
set_property(TARGET editorconfig_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(editorconfig_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libeditorconfig.so"
  IMPORTED_SONAME_RELEASE "libeditorconfig.so"
  )

list(APPEND _cmake_import_check_targets editorconfig_shared )
list(APPEND _cmake_import_check_files_for_editorconfig_shared "/data/data/com.clandro/files/usr/lib/libeditorconfig.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
