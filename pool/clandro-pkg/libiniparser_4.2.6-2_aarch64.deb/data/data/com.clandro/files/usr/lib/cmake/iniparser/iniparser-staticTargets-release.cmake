#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "iniparser-static" for configuration "Release"
set_property(TARGET iniparser-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(iniparser-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libiniparser.a"
  )

list(APPEND _cmake_import_check_targets iniparser-static )
list(APPEND _cmake_import_check_files_for_iniparser-static "/data/data/com.clandro/files/usr/lib/libiniparser.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
