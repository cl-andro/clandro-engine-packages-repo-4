#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "iniparser-shared" for configuration "Release"
set_property(TARGET iniparser-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(iniparser-shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.clandro/files/usr/lib/libiniparser.so"
  IMPORTED_SONAME_RELEASE "libiniparser.so"
  )

list(APPEND _cmake_import_check_targets iniparser-shared )
list(APPEND _cmake_import_check_files_for_iniparser-shared "/data/data/com.clandro/files/usr/lib/libiniparser.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
