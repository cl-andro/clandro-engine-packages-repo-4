#ifndef __LIBBTRFS_VERSION_H__
#define __LIBBTRFS_VERSION_H__

#define BTRFS_LIB_MAJOR		0
#define BTRFS_LIB_MINOR		1
#define BTRFS_LIB_PATCHLEVEL	5

#define BTRFS_LIB_VERSION ( BTRFS_LIB_MAJOR * 10000 + \
                            BTRFS_LIB_MINOR * 100 + \
                            BTRFS_LIB_PATCHLEVEL )

#define BTRFS_BUILD_VERSION "Btrfs v6.19.1"

#endif
